package control;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.GregorianCalendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.VoloDAO;
import model.Volo;

/**
 * Servlet implementation class inserimentoVolo
 */
@WebServlet("/inserimentoVolo")
public class inserimentoVolo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String aereoportoPartenza = request.getParameter("ARpartenza");
		String aereoportoArrivo = request.getParameter("ARarrivo");
		String data = request.getParameter("data");
		String oraPartenza =request.getParameter("oraP");
		String minutoPartenza = request.getParameter("minutoP");
		String oraArrivo = request.getParameter("oraA");
		String minutoArrivo = request.getParameter("minutoA");
		double economy = Double.parseDouble(request.getParameter("economy"));
		double business =  Double.parseDouble(request.getParameter("business"));
		double premium =  Double.parseDouble(request.getParameter("premium"));
		int aereo = Integer.parseInt(request.getParameter("Aereo"));
		String durata = calcolaDurataVolo( Integer.parseInt(oraPartenza) ,  Integer.parseInt(minutoPartenza) ,  Integer.parseInt(oraArrivo),  Integer.parseInt(minutoArrivo));
		Volo v = new Volo (aereoportoPartenza, aereoportoArrivo, data, oraPartenza+":"+minutoPartenza,oraArrivo+":"+minutoArrivo, durata, economy, business, premium, aereo);
		VoloDAO voloDao = new VoloDAO();
		voloDao.doSave(v);
		RequestDispatcher d= request.getRequestDispatcher("AdminVisualizzaVoli");
		d.forward(request, response);
	}
	
	private String calcolaDurataVolo(int oraPartenza , int minutoPartenza , int oraArrivo , int minutoArrivo) {
		int tempoP = (oraPartenza*3600)+(minutoPartenza*60);
		int tempoA = (oraArrivo*3600)+(minutoArrivo*60);
		int durata = tempoA - tempoP;
		int minutes = durata / 60;
		int hours = minutes / 60;
	    minutes %= 60;
	    return String.format("%02d:%02d:%02d", hours, minutes,0);
	}

}
