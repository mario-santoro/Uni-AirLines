package model;

import java.util.ArrayList;
import java.util.GregorianCalendar;

public class Prenotazione {
	private int codPrenotazione;
	private GregorianCalendar data;
	private String ora;
	private double prezzoTotale;
	private String proprietarioCarta;
	private int numCarta;
	private GregorianCalendar scadenzaCarta;
	private int cvv;
	private int numBiglietti;
	private String email;
	private int codVolo;
	private boolean isChangeVolo;
	private ArrayList<Passeggero> passeggeri;
	
	
	public Prenotazione() {}
	
	
	public Prenotazione(int codPrenotazione, GregorianCalendar data, String ora, double prezzoTotale,
			String proprietarioCarta, int numCarta, GregorianCalendar scadenzaCarta, int cvv, int numBiglietti,
			String email, int codVolo, boolean isChangeVolo, ArrayList<Passeggero> passeggeri) {
		this.codPrenotazione = codPrenotazione;
		this.data = data;
		this.ora = ora;
		this.prezzoTotale = prezzoTotale;
		this.proprietarioCarta = proprietarioCarta;
		this.numCarta = numCarta;
		this.scadenzaCarta = scadenzaCarta;
		this.cvv = cvv;
		this.numBiglietti = numBiglietti;
		this.email = email;
		this.codVolo = codVolo;
		this.isChangeVolo = isChangeVolo;
		this.passeggeri = passeggeri;
	}


	public int getCodPrenotazione() {
		return codPrenotazione;
	}


	public void setCodPrenotazione(int codPrenotazione) {
		this.codPrenotazione = codPrenotazione;
	}


	public GregorianCalendar getData() {
		return data;
	}


	public void setData(GregorianCalendar data) {
		this.data = data;
	}


	public String getOra() {
		return ora;
	}


	public void setOra(String ora) {
		this.ora = ora;
	}


	public double getPrezzoTotale() {
		return prezzoTotale;
	}


	public void setPrezzoTotale(double prezzoTotale) {
		this.prezzoTotale = prezzoTotale;
	}


	public String getProprietarioCarta() {
		return proprietarioCarta;
	}


	public void setProprietarioCarta(String proprietarioCarta) {
		this.proprietarioCarta = proprietarioCarta;
	}


	public int getNumCarta() {
		return numCarta;
	}


	public void setNumCarta(int numCarta) {
		this.numCarta = numCarta;
	}


	public GregorianCalendar getScadenzaCarta() {
		return scadenzaCarta;
	}


	public void setScadenzaCarta(GregorianCalendar scadenzaCarta) {
		this.scadenzaCarta = scadenzaCarta;
	}


	public int getCvv() {
		return cvv;
	}


	public void setCvv(int cvv) {
		this.cvv = cvv;
	}


	public int getNumBiglietti() {
		return numBiglietti;
	}


	public void setNumBiglietti(int numBiglietti) {
		this.numBiglietti = numBiglietti;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public int getCodVolo() {
		return codVolo;
	}


	public void setCodVolo(int codVolo) {
		this.codVolo = codVolo;
	}


	public boolean isChangeVolo() {
		return isChangeVolo;
	}


	public void setChangeVolo(boolean isChangeVolo) {
		this.isChangeVolo = isChangeVolo;
	}


	public ArrayList<Passeggero> getPasseggeri() {
		return passeggeri;
	}


	public void setPasseggeri(ArrayList<Passeggero> passeggeri) {
		this.passeggeri = passeggeri;
	}
	
	
	
	}
