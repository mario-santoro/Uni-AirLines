package dao;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import model.Volo;

public class VoloDAO {
	public synchronized boolean doSave(Volo v){
		
		Connection conn = null;
		PreparedStatement cmd = null;
		try {
	
			conn = DriverManagerConnectionPool.getConnection();
			

		
				String sql = "INSERT INTO volo(aereoportoPartenza,aereoportoDestinazione,dat,oraPartenza,"
						+ "oraArrivo,durataVolo,prezzoEconomy,prezzoBusiness,prezzoPremium,cod_aereo)"
						+ " VALUES(?,?,?,?,?,?,?,?,?,?)";
				cmd = (PreparedStatement) conn.prepareStatement(sql);
				cmd.setString(1,v.getAereoportoPartenza());
				cmd.setString(2, v.getAereoportoDestinazione());
				cmd.setString(3, v.getData() );
				cmd.setString(4, v.getOraPartenza());
				cmd.setString(5, v.getOraArrivo());
				cmd.setString(6, v.getDurataVolo());
				cmd.setDouble(7, v.getPrezzoEconomy());
				cmd.setDouble(8, v.getPrezzoBusiness());
				cmd.setDouble(9, v.getPrezzoPremium());
				cmd.setInt(10, v.getCod_aereo());
				cmd.executeUpdate();
				cmd.close();
				return true;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				cmd.close();
				DriverManagerConnectionPool.releaseConnection(conn);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return false;
	}
	
	public synchronized void doUpdate(Volo v) {

		Connection conn = null;
		PreparedStatement cmd = null;

		try {
			conn = DriverManagerConnectionPool.getConnection();

			String sql = " UPDATE volo SET aereoportoPartenza=?,aereoportoDestinazione=?,dat=?,oraPartenza=?,"
						+ "oraArrivo=?,durataVolo=?,prezzoEconomy=?,prezzoBusiness=?,prezzoPremium=?,cod_aereo=?  where codVolo=?";
			cmd = (PreparedStatement) conn.prepareStatement(sql);
			cmd.setString(1,v.getAereoportoPartenza());
			cmd.setString(2, v.getAereoportoDestinazione());
			cmd.setString(3, v.getData() );
			cmd.setString(4, v.getOraPartenza());
			cmd.setString(5, v.getOraArrivo());
			cmd.setString(6, v.getDurataVolo());
			cmd.setDouble(7, v.getPrezzoEconomy());
			cmd.setDouble(8, v.getPrezzoBusiness());
			cmd.setDouble(9, v.getPrezzoPremium());
			cmd.setInt(10, v.getCod_aereo());
			cmd.setInt(11, v.getCodVolo());
			cmd.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				cmd.close();
				DriverManagerConnectionPool.releaseConnection(conn);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
	}

	public synchronized void doDelete(Volo v) {

		Connection conn = null;
		PreparedStatement cmd = null;

		try {
			conn = DriverManagerConnectionPool.getConnection();

			String sql = "delete from volo  where codVolo=?";
			cmd = (PreparedStatement) conn.prepareStatement(sql);
		
			cmd.setInt(1, v.getCodVolo());
			cmd.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				cmd.close();
				DriverManagerConnectionPool.releaseConnection(conn);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
	}
	
	public synchronized ArrayList<Volo> showAll(String dataV,String ora) {

		ArrayList<Volo> voli = new ArrayList<Volo>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			Volo v;
			conn = DriverManagerConnectionPool.getConnection();

			String sql = "SELECT * FROM `volo` WHERE dat>? or (dat=? and oraPartenza>?)";
			ps = (PreparedStatement) conn.prepareStatement(sql);
			ps.setString(1,dataV);
			ps.setString(2,dataV);
			ps.setString(3,ora);
			rs = ps.executeQuery();
			

			while (rs.next()) {
				v = new Volo();
						v.setCodVolo(rs.getInt("codVolo"));
						v.setAereoportoPartenza(rs.getString("aereoportoPartenza"));
						v.setAereoportoDestinazione(rs.getString("aereoportoDestinazione"));
						v.setData(rs.getString("dat")) ;
						v.setOraPartenza(rs.getString("oraPartenza"));
						v.setOraArrivo(rs.getString("oraArrivo"));
						v.setDurataVolo(rs.getString("durataVolo"));
						v.setPrezzoEconomy(rs.getDouble("prezzoEconomy"));
						v.setPrezzoBusiness(rs.getDouble("prezzoBusiness"));
						v.setPrezzoPremium(rs.getDouble("prezzoPremium"));
						v.setCod_aereo(rs.getInt("cod_aereo"));
				
				voli.add(v);
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				DriverManagerConnectionPool.releaseConnection(conn);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return voli;
	}

}
