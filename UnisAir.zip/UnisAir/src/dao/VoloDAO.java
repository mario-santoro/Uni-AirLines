package dao;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.GregorianCalendar;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import model.Utente;
import model.Volo;

public class VoloDAO {
	public synchronized boolean doSave(Volo v){
		
		Connection conn = null;
		PreparedStatement cmd = null;
		try {
	
			conn = DriverManagerConnectionPool.getConnection();
			

		
				String sql = "INSERT INTO volo(aeroportoPartenza,aeroportoDestinazione,dat,oraPartenza,"
						+ "oraArrivo,durataVolo,prezzoEconomy,prezzoBusiness,prezzoPremium,cod_aereo)"
						+ " VALUES(?,?,?,?,?,?,?,?,?,?)";
				cmd = (PreparedStatement) conn.prepareStatement(sql);
				cmd.setString(1,v.getAereoportoPartenza());
				cmd.setString(2, v.getAereoportoDestinazione());
				cmd.setString(3, v.getData() );
				cmd.setString(4, v.getOraPartenza());
				cmd.setString(5, v.getOraArrivo());
				cmd.setString(6, v.getDurataVolo());
				cmd.setDouble(7, v.getPrezzoEconomy());
				cmd.setDouble(8, v.getPrezzoBusiness());
				cmd.setDouble(9, v.getPrezzoPremium());
				cmd.setInt(10, v.getCod_aereo());
				cmd.executeUpdate();
				cmd.close();
				return true;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				cmd.close();
				DriverManagerConnectionPool.releaseConnection(conn);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return false;
	}
	
	public synchronized void doUpdate(Volo v) {

		Connection conn = null;
		PreparedStatement cmd = null;

		try {
			conn = DriverManagerConnectionPool.getConnection();

			String sql = " UPDATE volo SET aeroportoPartenza=?,aeroportoDestinazione=?,dat=?,oraPartenza=?,"
						+ "oraArrivo=?,durataVolo=?,prezzoEconomy=?,prezzoBusiness=?,prezzoPremium=?,cod_aereo=?  where codVolo=?";
			cmd = (PreparedStatement) conn.prepareStatement(sql);
			cmd.setString(1,v.getAereoportoPartenza());
			cmd.setString(2, v.getAereoportoDestinazione());
			cmd.setString(3, v.getData() );
			cmd.setString(4, v.getOraPartenza());
			cmd.setString(5, v.getOraArrivo());
			cmd.setString(6, v.getDurataVolo());
			cmd.setDouble(7, v.getPrezzoEconomy());
			cmd.setDouble(8, v.getPrezzoBusiness());
			cmd.setDouble(9, v.getPrezzoPremium());
			cmd.setInt(10, v.getCod_aereo());
			cmd.setInt(11, v.getCodVolo());
			cmd.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				cmd.close();
				DriverManagerConnectionPool.releaseConnection(conn);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
	}

	public synchronized void doDelete(Volo v) {

		Connection conn = null;
		PreparedStatement cmd = null;

		try {
			conn = DriverManagerConnectionPool.getConnection();

			String sql = "delete from volo  where codVolo=?";
			cmd = (PreparedStatement) conn.prepareStatement(sql);
		
			cmd.setInt(1, v.getCodVolo());
			cmd.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				cmd.close();
				DriverManagerConnectionPool.releaseConnection(conn);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
	}
	
	public synchronized void showAll() {

		Connection conn = null;
		PreparedStatement cmd = null;
		GregorianCalendar data=new GregorianCalendar();
		String giorno = "" + data.get(Calendar.DAY_OF_MONTH);
		String mese = "" + data.get(Calendar.MONTH) + 1;
		String anno = "" + data.get(Calendar.YEAR);
		String dataV = anno+"-" + mese+"-"  + giorno;
		String ora = data.get(Calendar.HOUR_OF_DAY) + ":" + data.get(Calendar.MINUTE) + ":"+ data.get(Calendar.SECOND);
		try {
			conn = DriverManagerConnectionPool.getConnection();

			String sql = "SELECT * FROM `volo` WHERE dat>? or (dat=? and oraPartenza>?)";
			cmd = (PreparedStatement) conn.prepareStatement(sql);
			cmd.setString(1,dataV);
			cmd.setString(2,dataV);
			cmd.setString(3,ora);
			
			cmd.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				cmd.close();
				DriverManagerConnectionPool.releaseConnection(conn);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
	}

}
