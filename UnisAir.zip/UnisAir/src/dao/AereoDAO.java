package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import model.Aereo;


public class AereoDAO {


	public synchronized boolean doSave(Aereo a1) {
		Connection conn = null;
		PreparedStatement cmd = null;

		try {
			conn = DriverManagerConnectionPool.getConnection(); 
			String NuovoAereo = "INSERT INTO aereo(cod_aereo,nomeAereo) VALUES(?,?)";
			cmd = (PreparedStatement) conn.prepareStatement(NuovoAereo);

			cmd.setInt(1, a1.getCodAereo());
			cmd.setString(2, a1.getNome());
			cmd.executeUpdate();


			for(int i=0; i<a1.getPosti().size() ; i++){

				String PostoAereo = "INSERT INTO posto(numPosto,codAereo,tipologia) VALUES(?,?,?)";
				cmd = (PreparedStatement) conn.prepareStatement(PostoAereo);
				cmd.setString(1, a1.getPosti().get(i).getNumPosto());
				cmd.setInt(2, a1.getCodAereo());
				cmd.setString(2, a1.getPosti().get(i).getTipologia());
				cmd.executeUpdate();


			}

			return true;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				cmd.close();
				DriverManagerConnectionPool.releaseConnection(conn);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return false;
	}




}
