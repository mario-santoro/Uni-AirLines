
$(document).ready(function(){ 
	
			
	$(".l").click(function(){
$("#menu").toggle();
  });
	

})

function on() {
          document.getElementById("overlay").style.display = "block";
        }
  function off() {
          document.getElementById("overlay").style.display = "none";
        }

  function onAereo() {
            document.getElementById("overlay2").style.display = "block";
          }
  

  function offAereo() {
      document.getElementById("overlay2").style.display = "none";
      
    }
  
  

