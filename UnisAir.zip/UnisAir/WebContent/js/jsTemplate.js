
$(document).ready(function(){ 
	

	
	$(".l").click(function(){
$("#menu").toggle();
  });
	

})

function on() {
          document.getElementById("overlay").style.display = "block";
        }
  function off() {
          document.getElementById("overlay").style.display = "none";
        }
